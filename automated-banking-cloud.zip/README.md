# Automated Banking Cloud (simple base)

Flask + SQLite banking service with a small web UI, ready to containerise and deploy to any cloud.

## Features
- Account registration and login (hashed passwords, bearer tokens)
- Deposit, withdraw, transfer between accounts (atomic DB transactions)
- Transaction history, balance check
- `/health` endpoint for cloud load balancers

## Run locally
    pip install -r requirements.txt
    python app.py            # http://localhost:5000

## Run with Docker
    docker build -t banking-cloud .
    docker run -p 8080:8080 -v bankdata:/data banking-cloud

## API
| Method | Endpoint | Body |
|---|---|---|
| POST | /api/register | name, password, initial_deposit |
| POST | /api/login | account_no, password |
| GET  | /api/balance | - |
| POST | /api/deposit | amount |
| POST | /api/withdraw | amount |
| POST | /api/transfer | to_account, amount |
| GET  | /api/transactions | - |

Send `Authorization: Bearer <token>` on all calls except register/login.

## Next steps
PostgreSQL, token expiry, rate limiting, HTTPS, OTP/2FA, admin dashboard, CI/CD.
